import argparse

import joblib
import tensorflow as tf

from rllab.misc.console import query_yes_no
from rllab.sampler.utils import rollout



# If the snapshot file use tensorflow, do:
# import tensorflow as tf
# with tf.Session():
#     [rest of the code]

fout = open('test_run.json','w')
with tf.Session() as sess:
    data = joblib.load('/home/aroraiiit/rllab/data/local/experiment/experiment_2018_02_14_20_28_28_0001/params.pkl')
    policy = data['policy']
    env = data['env']
    while True:
        path = rollout(env, policy, max_path_length=1000,
                       animated=False, speedup=1)
        print(path)
        if not query_yes_no('Continue simulation?'):
            break
